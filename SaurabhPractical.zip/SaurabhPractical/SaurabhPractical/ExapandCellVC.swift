//
//  ExapandCellVC.swift
//  SaurabhPractical
//
//  Created by S@ur@bh on 12/9/19.
//  Copyright © 2019 S@ur@bh. All rights reserved.
//

import UIKit

class ExpandCell:UITableViewCell{
    @IBOutlet weak var lblName: UILabel!
}

class ExapandCellVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    @IBOutlet var tblviewExpand : UITableView!

    //var arrayHeader = [1, 1, 1, 1]
    var sectionNames: Array<Any> = []
    var expandData = [NSMutableDictionary]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
            sectionNames = [ "iPhone", "iPad", "Apple Watch" ];
        self.expandData.append(["isOpen":"1","data":["iPhone 5","iPhone 5s","iPhone 6","iPhone 6 Plus","iPhone 7","iPhone 7 Plus"]])
        self.expandData.append(["isOpen":"1","data":["iPad Mini","iPad Air 2","iPad Pro","iPad Pro 9.7"]])
        self.expandData.append(["isOpen":"1","data":["Apple Watch","Apple Watch 2","Apple Watch 2 (Nike)"]])
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.expandData.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.expandData[section].value(forKey: "isOpen") as! String == "1"{
            return 0
        }else{
            let dataarray = self.expandData[section].value(forKey: "data") as! NSArray
            return dataarray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ExpandCell
        let dataarray = self.expandData[indexPath.section].value(forKey: "data") as! NSArray
        cell.lblName.text = dataarray[indexPath.row] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
        {
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 30))
            headerView.backgroundColor = #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)
            
         // headerView.backgroundColor = ColorLiteral
            
            let label = UILabel(frame: CGRect(x: 5, y: 3, width: headerView.frame.size.width - 5, height: 27))
            label.text = self.sectionNames[section] as? String//"\(section)"
            headerView.addSubview(label)
            headerView.tag = section + 100
            
            let headerFrame = self.view.frame.size
            let theImageView = UIImageView(frame: CGRect(x: headerFrame.width - 32, y: 13, width: 22, height: 22));
            theImageView.tintColor = UIColor.black
            if(self.expandData[(headerView.tag) - 100].value(forKey: "isOpen") as! String == "1")
            {
                theImageView.image = UIImage(named: "plus")
            }
            else
            {
                theImageView.image = UIImage(named: "minus")
            }
            
            theImageView.tag = section + 100
            headerView.addSubview(theImageView)
            
            let tapgesture = UITapGestureRecognizer(target: self , action: #selector(self.sectionTapped(_:)))
            headerView.addGestureRecognizer(tapgesture)
            return headerView
        }
    
    @objc func sectionTapped(_ sender: UITapGestureRecognizer){
        
            if(self.expandData[(sender.view?.tag)! - 100].value(forKey: "isOpen") as! String == "1"){
                self.expandData[(sender.view?.tag)! - 100].setValue("0", forKey: "isOpen")
               
            }else{
              self.expandData[(sender.view?.tag)! - 100].setValue("1", forKey: "isOpen")
               
            }
            tblviewExpand.reloadSections(IndexSet(integer: (sender.view?.tag)! - 100), with: .automatic)
        }
    //}
    
   /* func numberOfSections(in tableView: UITableView) -> Int {
              return arrayHeader.count
          }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return (self.arrayHeader[section] == 0) ? 0 : 4
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
           cell.textLabel?.text = "section: \(indexPath.section)  row: \(indexPath.row)"
           return cell
       }
       
       func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 40
       }
       
       func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 40))
                  viewHeader.backgroundColor = UIColor.darkGray // Changing the header background color to gray
                  let button = UIButton(type: .custom)
                  button.frame = viewHeader.bounds
                  button.tag = section // Assign section tag to this button
                  button.addTarget(self, action: #selector(tapSection(sender:)), for: .touchUpInside)
                  button.setTitle("Section: \(section)", for: .normal)
                  viewHeader.addSubview(button)
                  return viewHeader
       }
       @objc func tapSection(sender: UIButton) {
           self.arrayHeader[sender.tag] = (self.arrayHeader[sender.tag] == 0) ? 1 : 0
           tblviewExpand.reloadSections([sender.tag], with: .fade)
       }*/
      
    
   
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


